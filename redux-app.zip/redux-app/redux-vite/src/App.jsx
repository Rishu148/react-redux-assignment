import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./components/Home";
import Profile from "./components/Profile";
import Settings from "./components/Settings";

const App = () => {
  const [formData, setFormData] = useState({ username: "", email: "", password: "" });
  const dispatch = useDispatch();
  const theme = useSelector((state) => state.theme.theme);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch({ type: "UPDATE_USER", payload: formData });
  };

  return (
    <Router>
      <div className={theme === "dark" ? "bg-gray-900 text-white min-h-screen p-5" : "bg-gray-100 text-black min-h-screen p-5"}>
        <nav className="mb-4 flex gap-4">
          <Link to="/">Home</Link>
          <Link to="/profile">Profile</Link>
          <Link to="/settings">Settings</Link>
        </nav>

        <form onSubmit={handleSubmit} className="mb-6 flex flex-col gap-2 max-w-sm">
          <input type="text" name="username" placeholder="Username" value={formData.username} onChange={handleChange} className="p-2 border" />
          <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} className="p-2 border" />
          <input type="password" name="password" placeholder="Password" value={formData.password} onChange={handleChange} className="p-2 border" />
          <button type="submit" className="bg-green-500 text-white py-2">Submit</button>
        </form>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;