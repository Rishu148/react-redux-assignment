import { useSelector } from "react-redux";

const Profile = () => {
  const { username, email } = useSelector((state) => state.user);
  const theme = useSelector((state) => state.theme.theme);

  return (
    <div className={theme === "dark" ? "bg-gray-800 text-white p-5" : "bg-white text-black p-5"}>
      <h2 className="text-lg font-semibold">Profile Info</h2>
      <p>Username: {username}</p>
      <p>Email: {email}</p>
    </div>
  );
};

export default Profile;