import { useSelector } from "react-redux";

const Home = () => {
  const theme = useSelector((state) => state.theme.theme);
  return (
    <div className={theme === "dark" ? "bg-gray-800 text-white p-5" : "bg-white text-black p-5"}>
      <h1 className="text-xl font-bold">Welcome to Home Page</h1>
    </div>
  );
};

export default Home;