import { combineReducers, createStore } from "redux";
import userReducer from "./reducers/checkReducer";
import themeReducer from "./reducers/themeReducer";

const rootReducer = combineReducers({
  user: userReducer,
  theme: themeReducer
});

const store = createStore(rootReducer);
store.subscribe(() => console.log("Store updated:", store.getState()));

export default store;