
import axios from 'axios';
import { API_URL } from '../../constants';

export const loginUser = (userData) => async (dispatch) => {
  try {
    dispatch({ type: 'LOGIN_REQUEST' });
    const res = await axios.post(`${API_URL}/api/user/login`, userData);
    dispatch({ type: 'LOGIN_SUCCESS', payload: res.data });
    localStorage.setItem('auth', JSON.stringify(res.data));
  } catch (err) {
    dispatch({ type: 'LOGIN_FAIL', payload: err.response.data.message });
  }
};
